package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;



@SpringBootApplication
@ComponentScan(basePackages = "/registrationBootApp/src/main/java/com/example/demo/controller/RegController.java")
public class RegistrationBootAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistrationBootAppApplication.class, args);
	}

}
