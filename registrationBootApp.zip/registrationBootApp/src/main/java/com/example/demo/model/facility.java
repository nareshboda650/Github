package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class facility
{

	@Id
	private int Hospital_ID;
	private String Hospital_Name;
	private String facility;
	private String  Description;
	private String Remarks;
	
	public int getHospital_ID() {
		return Hospital_ID;
	}
	public void setHospital_ID(int hospital_ID) {
		Hospital_ID = hospital_ID;
	}
	public String getHospital_Name() {
		return Hospital_Name;
	}
	public void setHospital_Name(String hospital_Name) {
		Hospital_Name = hospital_Name;
	}
	public String getFacility() {
		return facility;
	}
	public void setFacility(String facility) {
		this.facility = facility;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public String getRemarks() {
		return Remarks;
	}
	public void setRemarks(String remarks) {
		Remarks = remarks;
	}
	@Override
	public String toString() {
		return "facility [Hospital_ID=" + Hospital_ID + ", Hospital_Name=" + Hospital_Name + ", facility=" + facility
				+ ", Description=" + Description + ", Remarks=" + Remarks + "]";
	}
	
	
}
