package com.example.demo.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.RegRapo;
import com.example.demo.model.facility;

@Controller
public class RegController 
{

	@Autowired
	RegRapo repo;
	
	//@RequestMapping("/addregistration")
	//public String addAlien(Patient patient)
	{
		//repo.save(patient);
		//return "Patient.jsp";
		
	}
	
	@RequestMapping("/addfacility")
	public String AddFacility(facility fac)
	{
		repo.save(fac);
		return "facility";
		
	}
	
	
}
